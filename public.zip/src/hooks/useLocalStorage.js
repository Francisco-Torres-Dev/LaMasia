import { useState, useEffect, useCallback } from 'react';
import StorageService from '../services/StorageService';

/**
 * Hook para sincronizar estado con LocalStorage.
 * @param {string} key
 * @param {*} initialValue
 */
export const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    return StorageService.get(key, initialValue);
  });

  const setValue = useCallback(
    (value) => {
      setStoredValue((prev) => {
        const next = value instanceof Function ? value(prev) : value;
        StorageService.set(key, next);
        return next;
      });
    },
    [key]
  );

  useEffect(() => {
    const fromStorage = StorageService.get(key);
    if (fromStorage !== null) {
      setStoredValue(fromStorage);
    }
  }, [key]);

  return [storedValue, setValue];
};

export default useLocalStorage;
