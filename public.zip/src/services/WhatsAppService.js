import { BUSINESS_INFO } from '../data/constants';
import { formatNumber } from '../utils/formatCurrency';

/**
 * Genera el mensaje de pedido para WhatsApp.
 * @param {Array} items - Items del carrito
 * @param {number} total - Total final
 * @returns {string}
 */
export const generateWhatsAppMessage = (items, total) => {
  const lines = items.map(
    (item) => `• ${item.quantity}x ${item.name}${item.details ? ` (${item.details})` : ''}`
  );

  return [
    `Hola ${BUSINESS_INFO.name}.`,
    '',
    'Quisiera realizar el siguiente pedido:',
    '',
    ...lines,
    '',
    `Total: $${formatNumber(total)}`,
    '',
    'Muchas gracias.',
  ].join('\n');
};

/**
 * Abre WhatsApp con el mensaje del pedido prellenado.
 * @param {Array} items
 * @param {number} total
 */
export const sendWhatsAppOrder = (items, total) => {
  const message = generateWhatsAppMessage(items, total);
  const encoded = encodeURIComponent(message);
  const phone = BUSINESS_INFO.whatsapp.replace('+', '');
  window.open(`https://wa.me/${phone}?text=${encoded}`, '_blank');
};

export default { generateWhatsAppMessage, sendWhatsAppOrder };
