const STORAGE_KEYS = {
  CART: 'lamasia_cart',
  COUPON: 'lamasia_coupon',
  PRODUCTS: 'lamasia_products',
  DRINKS: 'lamasia_drinks',
  PROMOTIONS: 'lamasia_promotions',
  COUPONS: 'lamasia_coupons',
  ADMIN_SESSION: 'lamasia_admin_session',
};

/**
 * Servicio genérico de persistencia en LocalStorage.
 */
export const StorageService = {
  get(key, fallback = null) {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  },

  set(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  },

  remove(key) {
    localStorage.removeItem(key);
  },

  keys: STORAGE_KEYS,
};

export default StorageService;
