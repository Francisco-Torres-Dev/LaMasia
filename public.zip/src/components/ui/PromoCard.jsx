import { motion } from 'framer-motion';
import { FaShoppingCart } from 'react-icons/fa';
import BadgeTag from './BadgeTag';
import { formatCurrency } from '../../utils/formatCurrency';
import './components.css';

/**
 * Tarjeta para promociones 2x1.
 */
const PromoCard = ({ promo, onAddToCart, index = 0 }) => {
  const handleAdd = () => {
    onAddToCart({
      id: promo.id,
      name: promo.title,
      price: promo.price,
      category: 'promocion',
      image: promo.image,
      description: promo.description,
    }, 1, `${promo.size} · ${promo.tier}`);
  };

  return (
    <motion.div
      className="promo-card"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      whileHover={{ y: -6 }}
    >
      <div className="promo-card-header">
        <BadgeTag tag={promo.tag} />
        <span className="promo-type-badge">{promo.type}</span>
      </div>
      <div className="promo-card-image">
        <img src={promo.image} alt={promo.title} loading="lazy" />
      </div>
      <div className="promo-card-body">
        <h3>{promo.title}</h3>
        <p className="promo-description">{promo.description}</p>
        <div className="promo-meta">
          <span className="promo-size">{promo.size}</span>
          <span className="promo-tier">{promo.tier}</span>
        </div>
        <div className="promo-options">
          <span className="promo-options-label">Opciones:</span>
          <div className="promo-options-list">
            {promo.options.map((opt) => (
              <span key={opt} className="promo-option-chip">{opt}</span>
            ))}
          </div>
        </div>
        <div className="promo-card-footer">
          <span className="promo-price">{formatCurrency(promo.price)}</span>
          <button type="button" className="btn-primary-masia btn-sm" onClick={handleAdd}>
            <FaShoppingCart /> Agregar
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default PromoCard;
