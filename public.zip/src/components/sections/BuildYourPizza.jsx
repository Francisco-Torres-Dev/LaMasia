import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { FaShoppingCart } from 'react-icons/fa';
import Swal from 'sweetalert2';
import SectionTitle from '../ui/SectionTitle';
import { buildPizzaConfig, PIZZA_IMAGES } from '../../data/initialData';
import { useCart } from '../../context/CartContext';
import { formatCurrency } from '../../utils/formatCurrency';
import '../ui/components.css';

/**
 * Constructor dinámico de pizza personalizada.
 */
const BuildYourPizza = () => {
  const { addToCart } = useCart();
  const [selectedExtras, setSelectedExtras] = useState([]);

  const toggleExtra = (extra) => {
    setSelectedExtras((prev) =>
      prev.some((e) => e.id === extra.id)
        ? prev.filter((e) => e.id !== extra.id)
        : [...prev, extra]
    );
  };

  const totalPrice = useMemo(() => {
    const extrasTotal = selectedExtras.reduce((sum, e) => sum + e.price, 0);
    return buildPizzaConfig.basePrice + extrasTotal;
  }, [selectedExtras]);

  const handleAddToCart = () => {
    const extrasNames = selectedExtras.map((e) => e.name).join(', ');
    const details = extrasNames
      ? `${buildPizzaConfig.size} · Extras: ${extrasNames}`
      : buildPizzaConfig.size;

    addToCart(
      {
        id: `custom-pizza-${Date.now()}`,
        name: 'Pizza Personalizada',
        price: totalPrice,
        category: 'custom',
        image: PIZZA_IMAGES.custom,
      },
      1,
      details
    );

    Swal.fire({
      icon: 'success',
      title: '¡Pizza agregada!',
      text: 'Tu pizza personalizada está en el carrito',
      timer: 1500,
      showConfirmButton: false,
    });

    setSelectedExtras([]);
  };

  return (
    <section id="arma-pizza" className="build-pizza-section">
      <div className="section-container">
        <SectionTitle subtitle="Crea tu Obra Maestra" title="Arma tu Pizza" />

        <div className="build-pizza-container">
          <div>
            <h4 style={{ marginBottom: '1rem', color: 'var(--color-light-gray)' }}>
              Ingredientes extra (base incluida: {buildPizzaConfig.baseIngredients.join(', ')})
            </h4>
            <div className="build-pizza-extras">
              {buildPizzaConfig.extras.map((extra) => {
                const isSelected = selectedExtras.some((e) => e.id === extra.id);
                return (
                  <label
                    key={extra.id}
                    className={`extra-item ${isSelected ? 'selected' : ''}`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleExtra(extra)}
                    />
                    <div className="extra-item-info">
                      <span className="extra-item-name">{extra.name}</span>
                      <span className="extra-item-price">+{formatCurrency(extra.price)}</span>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          <motion.div
            className="build-pizza-summary"
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h3>Tu Pizza</h3>
            <div className="build-base-info">
              <p><strong>Tamaño:</strong> {buildPizzaConfig.size}</p>
              <p><strong>Base:</strong> {buildPizzaConfig.baseIngredients.join(', ')}</p>
              <p><strong>Precio base:</strong> {formatCurrency(buildPizzaConfig.basePrice)}</p>
            </div>

            {selectedExtras.length > 0 && (
              <div className="build-selected-extras">
                <h4>Ingredientes seleccionados</h4>
                <ul>
                  {selectedExtras.map((extra) => (
                    <li key={extra.id}>
                      <span>{extra.name}</span>
                      <span>{formatCurrency(extra.price)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="build-total">
              <span>Total</span>
              <span className="build-total-price">{formatCurrency(totalPrice)}</span>
            </div>

            <button type="button" className="btn-primary-masia" style={{ width: '100%' }} onClick={handleAddToCart}>
              <FaShoppingCart /> Agregar al Carrito
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default BuildYourPizza;
