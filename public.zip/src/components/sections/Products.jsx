import Swal from 'sweetalert2';
import SectionTitle from '../ui/SectionTitle';
import ProductCard from '../ui/ProductCard';
import { useCart } from '../../context/CartContext';
import '../ui/components.css';

/**
 * Sección general de productos destacados.
 */
const Products = () => {
  const { allProducts, addToCart } = useCart();
  const featured = allProducts.filter((p) => p.active && p.category !== 'bebidas').slice(0, 6);

  const handleAdd = (product) => {
    addToCart(product);
    Swal.fire({
      icon: 'success',
      title: '¡Agregado!',
      text: `${product.name} añadido al carrito`,
      timer: 1500,
      showConfirmButton: false,
    });
  };

  return (
    <section id="productos">
      <div className="section-container">
        <SectionTitle subtitle="Nuestra Carta" title="Productos Destacados" />
        <div className="products-grid">
          {featured.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={handleAdd}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Products;
