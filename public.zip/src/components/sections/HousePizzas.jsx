import Swal from 'sweetalert2';
import SectionTitle from '../ui/SectionTitle';
import ProductCard from '../ui/ProductCard';
import { useCart } from '../../context/CartContext';
import '../ui/components.css';

/**
 * Sección Pizzas de la Casa.
 */
const HousePizzas = () => {
  const { products, addToCart } = useCart();
  const housePizzas = products.filter((p) => p.category === 'pizzas-casa' && p.active);

  const handleAdd = (product) => {
    addToCart(product);
    Swal.fire({
      icon: 'success',
      title: '¡Agregado!',
      text: `${product.name} añadida al carrito`,
      timer: 1500,
      showConfirmButton: false,
    });
  };

  return (
    <section id="pizzas-casa">
      <div className="section-container">
        <SectionTitle subtitle="Recetas Exclusivas" title="Pizzas de la Casa" />
        <div className="products-grid">
          {housePizzas.map((product, index) => (
            <ProductCard
              key={product.id}
              product={product}
              onAddToCart={handleAdd}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default HousePizzas;
