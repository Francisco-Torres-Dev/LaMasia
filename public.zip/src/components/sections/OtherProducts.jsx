import Swal from 'sweetalert2';
import SectionTitle from '../ui/SectionTitle';
import ProductCard from '../ui/ProductCard';
import { useCart } from '../../context/CartContext';
import '../ui/components.css';

/**
 * Sección Otros Productos (papitas, stromboli).
 */
const OtherProducts = () => {
  const { products, drinks, addToCart } = useCart();
  const others = products.filter((p) => p.category === 'otros' && p.active);

  const handleAdd = (product) => {
    addToCart(product);
    Swal.fire({
      icon: 'success',
      title: '¡Agregado!',
      text: `${product.name} añadido al carrito`,
      timer: 1500,
      showConfirmButton: false,
    });
  };

  const drinksByBrand = drinks.reduce((acc, drink) => {
    if (!drink.active) return acc;
    if (!acc[drink.brand]) acc[drink.brand] = [];
    acc[drink.brand].push(drink);
    return acc;
  }, {});

  return (
    <>
      <section id="otros-productos" className="section-alt-bg">
        <div className="section-container">
          <SectionTitle subtitle="Más Delicias" title="Otros Productos" />
          <div className="products-grid">
            {others.map((product, index) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAdd}
                index={index}
              />
            ))}
          </div>
        </div>
      </section>

      <section id="bebidas">
        <div className="section-container">
          <SectionTitle subtitle="Para Acompañar" title="Bebidas" />
          {Object.entries(drinksByBrand).map(([brand, brandDrinks]) => (
            <div key={brand} className="drink-brand-group">
              <h3 className="drink-brand-title">{brand}</h3>
              <div className="drink-items">
                {brandDrinks.map((drink) => (
                  <div key={drink.id} className="drink-item">
                    <div className="drink-item-info">
                      <div className="drink-item-name">{drink.name}</div>
                      <div className="drink-item-variant">{drink.variant}</div>
                    </div>
                    <span className="drink-item-price">
                      ${drink.price.toLocaleString('es-CL')}
                    </span>
                    <button
                      type="button"
                      className="drink-add-btn"
                      onClick={() => handleAdd(drink)}
                      aria-label={`Agregar ${drink.name}`}
                    >
                      +
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default OtherProducts;
