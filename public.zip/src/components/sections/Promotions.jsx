import Swal from 'sweetalert2';
import SectionTitle from '../ui/SectionTitle';
import PromoCard from '../ui/PromoCard';
import { useCart } from '../../context/CartContext';
import '../ui/components.css';

/**
 * Sección de promociones 2x1.
 */
const Promotions = () => {
  const { promotions, addToCart } = useCart();
  const activePromos = promotions.filter((p) => p.active);

  const handleAdd = (product, qty, details) => {
    addToCart(product, qty, details);
    Swal.fire({
      icon: 'success',
      title: '¡Promoción agregada!',
      text: `${product.name} añadida al carrito`,
      timer: 1500,
      showConfirmButton: false,
    });
  };

  const medianas = activePromos.filter((p) => p.size === 'Mediana');
  const familiares = activePromos.filter((p) => p.size === 'Familiar');

  return (
    <section id="promociones" className="section-alt-bg">
      <div className="section-container">
        <SectionTitle subtitle="Ofertas Especiales" title="Promociones" />

        <h3 style={{ marginBottom: '1.5rem', fontSize: '1.3rem' }}>Promoción 2x1 Medianas</h3>
        <div className="promo-grid" style={{ marginBottom: '3rem' }}>
          {medianas.map((promo, index) => (
            <PromoCard key={promo.id} promo={promo} onAddToCart={handleAdd} index={index} />
          ))}
        </div>

        <h3 style={{ marginBottom: '1.5rem', fontSize: '1.3rem' }}>Promoción 2x1 Familiares</h3>
        <div className="promo-grid">
          {familiares.map((promo, index) => (
            <PromoCard key={promo.id} promo={promo} onAddToCart={handleAdd} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Promotions;
