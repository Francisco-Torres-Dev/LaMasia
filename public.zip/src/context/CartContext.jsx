import { createContext, useContext, useMemo, useCallback } from 'react';
import { generateId } from '../utils/generateId';
import { useLocalStorage } from '../hooks/useLocalStorage';
import StorageService from '../services/StorageService';
import {
  initialProducts,
  initialDrinks,
  initialPromotions,
  initialCoupons,
} from '../data/initialData';

const CartContext = createContext(null);

const calculateDiscount = (subtotal, coupon) => {
  if (!coupon) return 0;

  if (coupon.type === 'percentage') {
    return Math.round(subtotal * (coupon.value / 100));
  }

  if (coupon.type === 'fixed') {
    return Math.min(coupon.value, subtotal);
  }

  return 0;
};

export const CartProvider = ({ children }) => {
  const [items, setItems] = useLocalStorage(StorageService.keys.CART, []);
  const [appliedCoupon, setAppliedCoupon] = useLocalStorage(
    StorageService.keys.COUPON,
    null
  );
  const [products, setProductsState] = useLocalStorage(
    StorageService.keys.PRODUCTS,
    initialProducts
  );
  const [drinks, setDrinksState] = useLocalStorage(
    StorageService.keys.DRINKS,
    initialDrinks
  );
  const [promotions, setPromotionsState] = useLocalStorage(
    StorageService.keys.PROMOTIONS,
    initialPromotions
  );
  const [coupons, setCouponsState] = useLocalStorage(
    StorageService.keys.COUPONS,
    initialCoupons
  );

  const allProducts = useMemo(
    () => [...products, ...drinks],
    [products, drinks]
  );

  const addToCart = useCallback(
    (product, quantity = 1, details = null) => {
      setItems((prev) => {
        const cartKey = details
          ? `${product.id}-${details}`
          : product.id;

        const existing = prev.find(
          (item) => item.cartKey === cartKey
        );

        if (existing) {
          return prev.map((item) =>
            item.cartKey === cartKey
              ? { ...item, quantity: item.quantity + quantity }
              : item
          );
        }

        return [
          ...prev,
          {
            cartKey,
            id: generateId(),
            productId: product.id,
            name: product.name,
            price: product.price,
            quantity,
            details,
            category: product.category || 'general',
            image: product.image,
          },
        ];
      });
    },
    [setItems]
  );

  const removeFromCart = useCallback(
    (cartKey) => {
      setItems((prev) =>
        prev.filter((item) => item.cartKey !== cartKey)
      );
    },
    [setItems]
  );

  const updateQuantity = useCallback(
    (cartKey, quantity) => {
      if (quantity <= 0) {
        setItems((prev) =>
          prev.filter((item) => item.cartKey !== cartKey)
        );
        return;
      }

      setItems((prev) =>
        prev.map((item) =>
          item.cartKey === cartKey
            ? { ...item, quantity }
            : item
        )
      );
    },
    [setItems]
  );

  const clearCart = useCallback(() => {
    setItems([]);
    setAppliedCoupon(null);
  }, [setItems, setAppliedCoupon]);

  const applyCoupon = useCallback(
    (code) => {
      const coupon = coupons.find(
        (c) =>
          c.code.toUpperCase() === code.toUpperCase() &&
          c.active
      );

      if (!coupon) {
        return {
          success: false,
          message: 'Cupón no válido',
        };
      }

      if (new Date(coupon.expirationDate) < new Date()) {
        return {
          success: false,
          message: 'Cupón expirado',
        };
      }

      if (coupon.currentUses >= coupon.usageLimit) {
        return {
          success: false,
          message: 'Cupón agotado',
        };
      }

      setAppliedCoupon(coupon);

      return {
        success: true,
        message: `Cupón ${coupon.code} aplicado`,
      };
    },
    [coupons, setAppliedCoupon]
  );

  const removeCoupon = useCallback(() => {
    setAppliedCoupon(null);
  }, [setAppliedCoupon]);

  const subtotal = useMemo(
    () =>
      items.reduce(
        (sum, item) => sum + item.price * item.quantity,
        0
      ),
    [items]
  );

  const discount = useMemo(
    () => calculateDiscount(subtotal, appliedCoupon),
    [subtotal, appliedCoupon]
  );

  const total = useMemo(
    () => Math.max(subtotal - discount, 0),
    [subtotal, discount]
  );

  const itemCount = useMemo(
    () =>
      items.reduce(
        (sum, item) => sum + item.quantity,
        0
      ),
    [items]
  );

  const value = useMemo(
    () => ({
      items,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      applyCoupon,
      removeCoupon,
      appliedCoupon,
      subtotal,
      discount,
      total,
      itemCount,
      products,
      drinks,
      promotions,
      coupons,
      allProducts,
      setProducts: setProductsState,
      setDrinks: setDrinksState,
      setPromotions: setPromotionsState,
      setCoupons: setCouponsState,
    }),
    [
      items,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      applyCoupon,
      removeCoupon,
      appliedCoupon,
      subtotal,
      discount,
      total,
      itemCount,
      products,
      drinks,
      promotions,
      coupons,
      allProducts,
    ]
  );

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);

  if (!context) {
    throw new Error(
      'useCart debe usarse dentro de CartProvider'
    );
  }

  return context;
};

export default CartContext;